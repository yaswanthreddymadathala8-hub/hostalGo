# HostelGo

A React Native + Expo starter for a hostel and PG discovery/booking marketplace.

## Run locally

1. Install Node.js (LTS) from https://nodejs.org/
2. Install Expo Go on your Android phone, or use an Android emulator.
3. Extract this project and open a terminal in the `HostelGo` folder.
4. Run:

   ```bash
   npm install
   npx expo start
   ```

5. Scan the QR code using Expo Go (Android) or the Camera app (iOS).

## Current starter features

- HostelGo branding and home screen
- Search by hostel name, city, area or type
- Sample boys hostel, girls hostel and PG listings
- Expandable listing details
- Demo booking request interaction
- Owner listing call-to-action

## Important

This is a front-end starter/demo. Sample listings are not real properties. Authentication, verified owner onboarding, live room inventory, maps, backend database, payment gateway, notifications, booking confirmation and admin moderation still need to be implemented and tested before public launch.

Never commit real API keys or passwords. Put secrets in environment variables and keep `.env` out of Git.
