import React, { useState } from "react";
import { SafeAreaView, View, Text, TextInput, ScrollView, TouchableOpacity, Image, StyleSheet } from "react-native";
import { StatusBar } from "expo-status-bar";

const listings = [
  { id: "1", name: "Green Stay Boys Hostel", area: "Guntur, Andhra Pradesh", price: "₹5,500 / month", type: "Boys Hostel", features: "Wi-Fi • Hot water • CCTV", rating: "4.6" },
  { id: "2", name: "Comfort Nest PG", area: "Vijayawada, Andhra Pradesh", price: "₹6,000 / month", type: "Co-living PG", features: "Food • Washing machine • Wi-Fi", rating: "4.4" },
  { id: "3", name: "Sri Lakshmi Girls Hostel", area: "Guntur, Andhra Pradesh", price: "₹5,000 / month", type: "Girls Hostel", features: "Security • Hot water • Food", rating: "4.7" }
];

export default function App() {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(null);
  const filtered = listings.filter(x => (x.name + x.area + x.type).toLowerCase().includes(query.toLowerCase()));

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.header}>
          <View>
            <Text style={styles.brand}>Hostel<Text style={styles.brandAccent}>Go</Text></Text>
            <Text style={styles.tagline}>Find your stay, anywhere.</Text>
          </View>
          <View style={styles.avatar}><Text style={styles.avatarText}>HG</Text></View>
        </View>

        <Text style={styles.heading}>Find a place to feel at home</Text>
        <Text style={styles.subheading}>Discover hostels, PGs and shared rooms across India.</Text>

        <View style={styles.searchBox}>
          <Text style={styles.searchIcon}>⌕</Text>
          <TextInput value={query} onChangeText={setQuery} placeholder="Search city, area or hostel" placeholderTextColor="#8A91A3" style={styles.searchInput} />
        </View>

        <Text style={styles.sectionTitle}>Explore stays</Text>
        <View style={styles.chips}>
          {["All stays", "Boys", "Girls", "PG"].map(label => (
            <TouchableOpacity key={label} style={styles.chip} onPress={() => setQuery(label === "All stays" ? "" : label === "PG" ? "PG" : label + " Hostel")}>
              <Text style={styles.chipText}>{label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.rowBetween}>
          <Text style={styles.sectionTitle}>Popular near you</Text>
          <Text style={styles.link}>View all</Text>
        </View>

        {filtered.map(item => (
          <TouchableOpacity key={item.id} style={styles.card} onPress={() => setSelected(selected?.id === item.id ? null : item)}>
            <View style={styles.photoPlaceholder}>
              <Text style={styles.photoEmoji}>🏠</Text>
              <Text style={styles.photoLabel}>HOSTEL PHOTO</Text>
            </View>
            <View style={styles.cardBody}>
              <View style={styles.rowBetween}>
                <Text style={styles.cardTitle}>{item.name}</Text>
                <Text style={styles.rating}>★ {item.rating}</Text>
              </View>
              <Text style={styles.location}>⌖ {item.area}</Text>
              <Text style={styles.features}>{item.features}</Text>
              <View style={styles.rowBetween}>
                <Text style={styles.price}>{item.price}</Text>
                <Text style={styles.type}>{item.type}</Text>
              </View>
              {selected?.id === item.id && (
                <View style={styles.details}>
                  <Text style={styles.detailsText}>Room availability and owner contact will appear here when the backend is connected.</Text>
                  <TouchableOpacity style={styles.bookButton} onPress={() => alert("Booking flow will be enabled after backend and payment setup.")}>
                    <Text style={styles.bookButtonText}>Request booking</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          </TouchableOpacity>
        ))}

        {filtered.length === 0 && <Text style={styles.empty}>No stays found. Try another city or hostel name.</Text>}

        <View style={styles.ownerBanner}>
          <Text style={styles.ownerTitle}>Own a hostel?</Text>
          <Text style={styles.ownerCopy}>List your property on HostelGo and reach more customers.</Text>
          <TouchableOpacity style={styles.ownerButton} onPress={() => alert("Owner registration will be added in the next development phase.")}>
            <Text style={styles.ownerButtonText}>List your property</Text>
          </TouchableOpacity>
        </View>
        <Text style={styles.footer}>HostelGo • Demo starter app</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F7F8FC" },
  container: { padding: 20, paddingBottom: 36 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 28 },
  brand: { fontSize: 27, fontWeight: "800", color: "#15213B" },
  brandAccent: { color: "#2864E8" },
  tagline: { color: "#778198", marginTop: 2 },
  avatar: { width: 42, height: 42, borderRadius: 21, backgroundColor: "#E5EDFF", alignItems: "center", justifyContent: "center" },
  avatarText: { color: "#2864E8", fontWeight: "800" },
  heading: { fontSize: 27, lineHeight: 34, fontWeight: "800", color: "#17233D", maxWidth: 310 },
  subheading: { color: "#788197", marginTop: 8, lineHeight: 21 },
  searchBox: { flexDirection: "row", alignItems: "center", backgroundColor: "#FFFFFF", borderRadius: 14, paddingHorizontal: 15, marginTop: 22, height: 54, borderWidth: 1, borderColor: "#E9ECF3" },
  searchIcon: { fontSize: 27, color: "#2864E8", marginRight: 9 },
  searchInput: { flex: 1, color: "#17233D", fontSize: 15 },
  sectionTitle: { fontSize: 18, fontWeight: "800", color: "#17233D", marginTop: 25, marginBottom: 13 },
  chips: { flexDirection: "row", gap: 9 },
  chip: { backgroundColor: "#EAF0FF", borderRadius: 20, paddingVertical: 9, paddingHorizontal: 15 },
  chipText: { color: "#285BCC", fontWeight: "700" },
  rowBetween: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  link: { color: "#2864E8", fontWeight: "700", marginTop: 12 },
  card: { backgroundColor: "#FFFFFF", borderRadius: 17, overflow: "hidden", marginBottom: 16, borderWidth: 1, borderColor: "#EDF0F5" },
  photoPlaceholder: { height: 135, backgroundColor: "#E8EEFA", alignItems: "center", justifyContent: "center" },
  photoEmoji: { fontSize: 39 },
  photoLabel: { color: "#7A87A1", fontSize: 10, letterSpacing: 1.5, fontWeight: "800", marginTop: 5 },
  cardBody: { padding: 15 },
  cardTitle: { color: "#17233D", fontSize: 16, fontWeight: "800", flex: 1, marginRight: 8 },
  rating: { color: "#B77812", fontWeight: "800" },
  location: { color: "#778197", marginTop: 7, fontSize: 13 },
  features: { color: "#59647A", marginTop: 10, fontSize: 12 },
  price: { color: "#17233D", fontWeight: "800", marginTop: 13, fontSize: 15 },
  type: { color: "#2864E8", backgroundColor: "#EEF3FF", overflow: "hidden", borderRadius: 8, paddingVertical: 5, paddingHorizontal: 8, fontSize: 11, fontWeight: "700", marginTop: 10 },
  details: { borderTopWidth: 1, borderTopColor: "#EDF0F5", marginTop: 13, paddingTop: 12 },
  detailsText: { color: "#68738A", lineHeight: 19, fontSize: 12 },
  bookButton: { backgroundColor: "#2864E8", borderRadius: 10, padding: 12, alignItems: "center", marginTop: 12 },
  bookButtonText: { color: "#FFFFFF", fontWeight: "800" },
  empty: { color: "#778197", textAlign: "center", padding: 25 },
  ownerBanner: { backgroundColor: "#172A52", borderRadius: 17, padding: 20, marginTop: 12 },
  ownerTitle: { color: "#FFFFFF", fontSize: 19, fontWeight: "800" },
  ownerCopy: { color: "#D5DDF0", marginTop: 7, lineHeight: 20 },
  ownerButton: { alignSelf: "flex-start", backgroundColor: "#FFFFFF", borderRadius: 10, paddingVertical: 11, paddingHorizontal: 15, marginTop: 15 },
  ownerButtonText: { color: "#1C4FB9", fontWeight: "800" },
  footer: { textAlign: "center", color: "#9AA2B2", fontSize: 11, marginTop: 25 }
});
